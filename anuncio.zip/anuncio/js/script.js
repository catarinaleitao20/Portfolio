function donate(){
	alert ('Thank you for the donation!');
	document.getElementById('donate').value = "Já doou";
	document.getElementById('donate').style.backgroundColor = "green";
}